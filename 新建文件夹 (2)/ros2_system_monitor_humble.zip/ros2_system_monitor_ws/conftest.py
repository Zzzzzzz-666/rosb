"""允许从源码根目录运行 pytest；colcon 构建后也能使用已安装包。"""
import sys
from pathlib import Path

root = Path(__file__).parent
for name in ('system_status_monitor', 'system_status_gui'):
    sys.path.insert(0, str(root / 'src' / name))
