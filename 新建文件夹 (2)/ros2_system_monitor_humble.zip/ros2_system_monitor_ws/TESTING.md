# 验证记录

目标运行环境：Ubuntu 22.04、ROS 2 Humble、Python 3.10、PyQt5。

## 本次实际执行

实际测试主机为 Windows，测试依赖安装在工作区独立虚拟环境中：Python 3.13.16、psutil 7.2.2、PyQt5 5.15.11、pytest 9.1.1。

1. `python -m pytest -q -p no:cacheprovider`：**21 passed, 1 skipped**。
   - 检查 CPU 初次采样预热和非阻塞调用。
   - 检查真实时间间隔的网速计算、网卡变更、计数器回退、空网卡列表。
   - 检查非法字段、缺字段、NaN、超范围使用率、不带时区的时间和超长消息。
   - 读取测试主机真实系统数据，完成 JSON 往返和 Qt 标签、进度条更新。
   - 检查等待、连接、数据过期、格式异常及恢复状态。
2. 按 Python 3.10 语法规则解析全部 14 个 Python 文件：通过。
3. XML 检查：恰好两个 ROS 包，名称为 `system_status_monitor` 和 `system_status_gui`。
4. 两个包的 wheel 构建：通过，包含 ament 资源索引、入口点和 GUI launch 文件。
5. Qt 窗口离屏渲染、人工查看：通过；`docs/preview.png` 使用**固定示例数据**，不是 ROS 实机运行截图。Windows 离屏渲染脚本显式加载系统字体；目标 Ubuntu 桌面使用正常 Qt 字体发现和 `fonts-noto-cjk`。

## 未在本机执行

本机没有 Ubuntu / ROS 2 Humble / rclpy，故未完成目标系统上的 `colcon build`、`ros2 launch` 和真实 DDS 端到端联调。Python wheel 构建不能替代 colcon 构建。

`test_ros_pipeline.py` 因缺少 rclpy 跳过；该文件没有用假 ROS 对象替代真实通信。请在目标 Ubuntu 环境按 README 构建并 source 后执行：

```bash
QT_QPA_PLATFORM=offscreen python3 -m pytest -q
```

依赖完整且 DDS 正常时，应有 **22 项通过、无跳过**，其中真实通信测试会检查发布→订阅→Qt 更新及日志写入。
