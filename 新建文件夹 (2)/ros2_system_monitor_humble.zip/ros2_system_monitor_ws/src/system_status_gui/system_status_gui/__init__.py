"""Qt display for system_status_monitor messages."""
