"""包 2：ROS 订阅与 Qt 主事件循环集成。"""

import math
import sys
import time

from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication
import rclpy
from rcl_interfaces.msg import ParameterDescriptor
from rclpy.executors import ExternalShutdownException, SingleThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String

from system_status_monitor.protocol import decode_status
from .window import StatusWindow


class StatusSubscriber(Node):
    def __init__(self, window, **kwargs):
        super().__init__('system_status_gui', **kwargs)
        self.window = window
        self.last_warning = -float('inf')
        readonly = ParameterDescriptor(read_only=True)
        self.declare_parameter('topic', '/system/status', readonly)
        self.declare_parameter('stale_timeout', 3.0, readonly)
        timeout = self.get_parameter('stale_timeout').value
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError('stale_timeout 必须是正的有限秒数')
        self.window.stale_timeout = timeout
        self.subscription = self.create_subscription(
            String, self.get_parameter('topic').value, self.on_status, 1)

    def on_status(self, message):
        try:
            data = decode_status(message.data)
        except (ValueError, TypeError, OverflowError, RecursionError) as exc:
            self.window.show_data_error(str(exc))
            now = time.monotonic()
            if now - self.last_warning >= 5:
                self.get_logger().warning(f'忽略无效状态消息：{exc}')
                self.last_warning = now
            return
        self.window.display_status(data)


def main(args=None):
    rclpy.init(args=args)
    # 不把 --ros-args 传给 Qt 命令行解析器。
    app = QApplication([sys.argv[0]])
    node = executor = timer = None
    window = StatusWindow()
    try:
        node = StatusSubscriber(window)
        executor = SingleThreadedExecutor()
        executor.add_node(node)

        def pump_ros():
            if not rclpy.ok():
                app.quit()
                return
            try:
                # 非阻塞，回调和 QWidget 更新都在 Qt 主线程执行。
                executor.spin_once(timeout_sec=0.0)
            except (ExternalShutdownException, KeyboardInterrupt):
                app.quit()
                return
            window.check_connection()

        timer = QTimer(window)
        timer.timeout.connect(pump_ros)
        timer.start(20)
        window.show()
        app.exec_()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if timer is not None:
            timer.stop()
        if executor is not None:
            executor.shutdown()
        if node is not None:
            node.destroy_node()
        window.close()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
