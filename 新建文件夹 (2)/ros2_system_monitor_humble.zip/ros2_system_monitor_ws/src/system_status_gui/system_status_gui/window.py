"""纯 Qt 界面：不在本地重新采集数据，只显示收到的消息。"""

import time
from datetime import datetime

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar,
    QVBoxLayout, QWidget,
)


def format_bytes(value):
    number = float(value)
    for unit in ('B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'):
        if number < 1024 or unit == 'PiB':
            return f'{number:.2f} {unit}'
        number /= 1024


class StatusWindow(QWidget):
    def __init__(self, stale_timeout=3.0):
        super().__init__()
        self.stale_timeout = stale_timeout
        self.last_received = None
        self.last_interval = 1.0
        self.last_error = None
        self.values = {}
        self.setWindowTitle('ROS 2 系统状态监视器')
        self.resize(680, 620)
        self.setMinimumSize(600, 560)
        self.setStyleSheet('''
            QWidget { background: #101824; color: #e5edf5;
                      font-family: "Noto Sans CJK SC", "Microsoft YaHei", sans-serif;
                      font-size: 14px; }
            QLabel#title { font-size: 25px; font-weight: bold; }
            QLabel#muted { color: #9cafc1; font-size: 12px; }
            QLabel#value { font-size: 23px; font-weight: bold; }
            QFrame#card { background: #1b2939; border: 1px solid #2e4257;
                         border-radius: 10px; }
            QFrame#card QLabel { background: transparent; border: none; }
            QProgressBar { border: none; background: #34465b; border-radius: 5px;
                           height: 10px; }
            QProgressBar::chunk { background: #54d6c6; border-radius: 5px; }
        ''')
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(14)
        heading = QHBoxLayout()
        title = QLabel('系统实时状态')
        title.setObjectName('title')
        self.connection = QLabel('等待数据')
        self.connection.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        heading.addWidget(title)
        heading.addWidget(self.connection)
        outer.addLayout(heading)
        self.host = QLabel('主机  —')
        self.host.setTextFormat(Qt.PlainText)
        self.host.setWordWrap(True)
        self.timestamp = QLabel('记录时间  —')
        self.timestamp.setObjectName('muted')
        self.timestamp.setWordWrap(True)
        outer.addWidget(self.host)
        outer.addWidget(self.timestamp)
        grid = QGridLayout()
        grid.setSpacing(12)
        self.cpu_bar = self.add_card(grid, 0, 0, 'CPU 使用率', 'cpu', True)
        self.memory_bar = self.add_card(grid, 0, 1, '内存使用率', 'memory', True)
        self.add_card(grid, 1, 0, '内存总大小', 'total')
        self.add_card(grid, 1, 1, '剩余内存（可用）', 'available')
        self.add_card(grid, 2, 0, '网络累计接收', 'received')
        self.add_card(grid, 2, 1, '网络累计发送', 'sent')
        self.add_card(grid, 3, 0, '实时接收速率', 'rx_rate')
        self.add_card(grid, 3, 1, '实时发送速率', 'tx_rate')
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        outer.addLayout(grid, 1)
        self.detail = QLabel('网卡  —  ·  采样间隔  —')
        self.detail.setObjectName('muted')
        self.detail.setTextFormat(Qt.PlainText)
        self.detail.setWordWrap(True)
        outer.addWidget(self.detail)
        hint = QLabel('剩余内存使用 available；网络累计量来自系统网卡计数器。')
        hint.setObjectName('muted')
        hint.setWordWrap(True)
        outer.addWidget(hint)
        self.check_connection()

    def add_card(self, grid, row, column, title, key, progress=False):
        card = QFrame()
        card.setObjectName('card')
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 11, 16, 11)
        label = QLabel(title)
        label.setObjectName('muted')
        value = QLabel('—')
        value.setObjectName('value')
        self.values[key] = value
        layout.addWidget(label)
        layout.addWidget(value)
        bar = None
        if progress:
            bar = QProgressBar()
            bar.setRange(0, 1000)
            bar.setValue(0)
            bar.setTextVisible(False)
            layout.addWidget(bar)
        grid.addWidget(card, row, column)
        return bar

    def display_status(self, data):
        self.last_received = time.monotonic()
        self.last_interval = data['sample_interval_sec']
        self.last_error = None
        self.host.setText('主机  ' + data['hostname'])
        stamp = datetime.fromisoformat(data['timestamp']).astimezone()
        self.timestamp.setText('记录时间  ' + stamp.strftime('%Y-%m-%d %H:%M:%S %z'))
        self.values['cpu'].setText(f"{data['cpu_percent']:.1f}%")
        self.values['memory'].setText(f"{data['memory_percent']:.1f}%")
        self.cpu_bar.setValue(round(data['cpu_percent'] * 10))
        self.memory_bar.setValue(round(data['memory_percent'] * 10))
        mapping = {
            'total': 'memory_total_bytes', 'available': 'memory_available_bytes',
            'received': 'network_received_bytes', 'sent': 'network_sent_bytes',
            'rx_rate': 'network_receive_bytes_per_sec',
            'tx_rate': 'network_send_bytes_per_sec',
        }
        for key, field in mapping.items():
            suffix = '/s' if key.endswith('_rate') else ''
            self.values[key].setText(format_bytes(data[field]) + suffix)
        self.values['available'].setToolTip(
            '完全空闲（free）：' + format_bytes(data['memory_free_bytes']))
        self.detail.setText(
            f"网卡  {data['network_interface']}  ·  "
            f"采样间隔 {data['sample_interval_sec']:.2f} s  ·  第 {data['sequence']} 次")
        self.check_connection()

    def show_data_error(self, reason):
        self.last_error = reason
        self.check_connection()

    def check_connection(self):
        if self.last_error:
            text, color = '数据格式异常', '#ffb86c'
        elif self.last_received is None:
            text, color = '等待发布端', '#ffb86c'
        elif time.monotonic() - self.last_received > max(
                self.stale_timeout, self.last_interval * 3):
            text, color = '数据已过期', '#ffb86c'
        else:
            text, color = '● 实时连接', '#54d6c6'
        self.connection.setText(text)
        self.connection.setStyleSheet(f'color: {color}; font-weight: bold;')
        self.connection.setToolTip(self.last_error or '断流时保留最后一条数据，并标记过期。')
