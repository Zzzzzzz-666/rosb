"""同时启动两个包；关闭 GUI 后结束整个演示。"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    publisher = Node(
        package='system_status_monitor', executable='status_publisher', output='screen',
        parameters=[{
            'publish_period': ParameterValue(LaunchConfiguration('period'), value_type=float),
            'topic': ParameterValue(LaunchConfiguration('topic'), value_type=str),
            'network_interface': ParameterValue(
                LaunchConfiguration('interface'), value_type=str),
            'log_file': ParameterValue(LaunchConfiguration('log_file'), value_type=str),
        }],
    )
    gui = Node(
        package='system_status_gui', executable='status_gui', output='screen',
        parameters=[{
            'topic': ParameterValue(LaunchConfiguration('topic'), value_type=str),
        }],
    )
    return LaunchDescription([
        DeclareLaunchArgument('period', default_value='1.0', description='采样周期，秒'),
        DeclareLaunchArgument('topic', default_value='/system/status'),
        DeclareLaunchArgument('interface', default_value='', description='留空统计全部网卡'),
        DeclareLaunchArgument('log_file', default_value='', description='可选 JSONL 日志路径'),
        RegisterEventHandler(OnProcessExit(
            target_action=gui,
            on_exit=[EmitEvent(event=Shutdown(reason='GUI 已关闭'))],
        )),
        publisher,
        gui,
    ])
