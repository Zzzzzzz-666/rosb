import os
import time

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PyQt5.QtWidgets import QApplication
from system_status_gui.window import StatusWindow, format_bytes
from system_status_monitor.metrics import MetricsCollector
from system_status_monitor.protocol import decode_status, encode_status


@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def test_units():
    assert format_bytes(0) == '0.00 B'
    assert format_bytes(1024) == '1.00 KiB'
    assert format_bytes(1024 ** 3) == '1.00 GiB'


def test_window_receives_real_sample_and_marks_stale(app):
    collector = MetricsCollector()
    time.sleep(0.15)
    data = decode_status(encode_status(collector.sample()))
    window = StatusWindow()
    assert window.connection.text() == '等待发布端'
    window.display_status(data)
    assert data['hostname'] in window.host.text()
    assert window.values['total'].text() == format_bytes(data['memory_total_bytes'])
    assert window.values['cpu'].text() == f"{data['cpu_percent']:.1f}%"
    assert window.cpu_bar.value() == round(data['cpu_percent'] * 10)
    assert window.connection.text() == '● 实时连接'
    window.last_received = time.monotonic() - 100
    window.check_connection()
    assert window.connection.text() == '数据已过期'
    window.show_data_error('测试错误')
    assert window.connection.text() == '数据格式异常'
    window.display_status(data)
    assert window.connection.text() == '● 实时连接'
    window.close()
