"""真实 ROS 发布→订阅→Qt 更新测试；没有 ROS 时明确跳过，不伪造通信。"""

import os
import time
import uuid

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest

rclpy = pytest.importorskip('rclpy', reason='需要 ROS 2 Humble 环境')

from PyQt5.QtWidgets import QApplication
from rclpy.executors import SingleThreadedExecutor
from rclpy.parameter import Parameter
from system_status_gui.gui_node import StatusSubscriber
from system_status_gui.window import StatusWindow
from system_status_monitor.publisher import StatusPublisher


def test_publisher_to_qt_over_ros(tmp_path):
    app = QApplication.instance() or QApplication([])
    rclpy.init(args=[])
    publisher = subscriber = executor = None
    window = StatusWindow()
    log_path = tmp_path / 'samples.jsonl'
    try:
        topic = '/system_status_test_' + uuid.uuid4().hex
        publisher = StatusPublisher(parameter_overrides=[
            Parameter('topic', value=topic),
            Parameter('publish_period', value=0.1),
            Parameter('log_file', value=str(log_path)),
        ])
        subscriber = StatusSubscriber(window, parameter_overrides=[
            Parameter('topic', value=topic),
        ])
        executor = SingleThreadedExecutor()
        executor.add_node(publisher)
        executor.add_node(subscriber)
        deadline = time.monotonic() + 8
        while window.last_received is None and time.monotonic() < deadline:
            executor.spin_once(timeout_sec=0.05)
            app.processEvents()
        assert window.last_received is not None, '8 秒内没有收到 DDS 消息'
        assert publisher.collector.hostname in window.host.text()
        assert window.connection.text() == '● 实时连接'
        assert log_path.read_text(encoding='utf-8').strip()
    finally:
        if executor is not None:
            executor.shutdown()
        for node in (subscriber, publisher):
            if node is not None:
                node.destroy_node()
        window.close()
        if rclpy.ok():
            rclpy.shutdown()
