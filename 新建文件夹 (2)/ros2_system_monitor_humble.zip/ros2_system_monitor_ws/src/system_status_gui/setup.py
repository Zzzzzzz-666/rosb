from glob import glob
from setuptools import find_packages, setup

package_name = 'system_status_gui'
setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Student',
    maintainer_email='student@example.com',
    description='Qt dashboard for the ROS 2 system status topic.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={'console_scripts': [
        'status_gui = system_status_gui.gui_node:main',
    ]},
)
