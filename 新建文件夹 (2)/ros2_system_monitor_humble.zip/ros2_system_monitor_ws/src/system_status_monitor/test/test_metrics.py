from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

from system_status_monitor.metrics import MetricsCollector, network_rate
from system_status_monitor.protocol import decode_status, encode_status


class FakeSystem:
    def __init__(self):
        self.rx = 1000
        self.tx = 2000
        self.cpu_calls = 0

    def cpu_percent(self, interval=None):
        assert interval is None  # 采集不得阻塞 ROS 定时回调。
        self.cpu_calls += 1
        return 0.0 if self.cpu_calls == 1 else 25.0

    def net_io_counters(self, pernic=True, nowrap=True):
        return {'eth0': SimpleNamespace(bytes_recv=self.rx, bytes_sent=self.tx)}

    def virtual_memory(self):
        return SimpleNamespace(total=16000, available=12000, free=1000, percent=25.0)


def sample_data():
    provider = FakeSystem()
    ticks = iter([10.0, 12.0])
    collector = MetricsCollector(
        provider=provider, clock=lambda: next(ticks),
        wall_clock=lambda: datetime(2026, 10, 11, tzinfo=timezone.utc))
    provider.rx += 600
    provider.tx += 200
    return collector.sample(), provider


def test_real_interval_and_cpu_warmup():
    data, provider = sample_data()
    assert provider.cpu_calls == 2
    assert data['cpu_percent'] == 25.0
    assert data['network_receive_bytes_per_sec'] == 300.0
    assert data['network_send_bytes_per_sec'] == 100.0
    assert data['memory_available_bytes'] == 12000
    assert data['memory_free_bytes'] == 1000
    assert data['sequence'] == 1
    assert decode_status(encode_status(data)) == data


@pytest.mark.parametrize('previous,current,elapsed,expected', [
    ({'a': (100, 100)}, {'a': (300, 500)}, 2, (100, 200)),
    ({'a': (100, 100)}, {'a': (10, 20)}, 1, (0, 0)),
    ({'a': (100, 100)}, {'b': (900, 900)}, 1, (0, 0)),
    ({'a': (100, 100)}, {'a': (300, 500)}, 0, (0, 0)),
    ({}, {}, 1, (0, 0)),
])
def test_network_discontinuities(previous, current, elapsed, expected):
    assert network_rate(previous, current, elapsed) == expected


def test_unknown_interface_fails_clearly():
    with pytest.raises(ValueError, match='找不到网卡'):
        MetricsCollector(interface='missing0', provider=FakeSystem())


@pytest.mark.parametrize('key,value', [
    ('cpu_percent', float('nan')),
    ('cpu_percent', 101),
    ('memory_available_bytes', 999999),
    ('network_received_bytes', -1),
    ('sample_interval_sec', 0),
    ('hostname', None),
    ('schema_version', True),
    ('timestamp', '2026-10-11T00:00:00'),
])
def test_invalid_status_rejected(key, value):
    data, _ = sample_data()
    data[key] = value
    with pytest.raises(ValueError):
        encode_status(data)


@pytest.mark.parametrize('text', ['not json', '[]', '{}', 'x' * 16385])
def test_invalid_wire_message_rejected(text):
    with pytest.raises(ValueError):
        decode_status(text)
