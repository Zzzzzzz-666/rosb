"""包 1：采集系统信息，以 std_msgs/String 中的 JSON 发布。"""

import math
from pathlib import Path

import rclpy
from rcl_interfaces.msg import ParameterDescriptor
from rclpy.clock import Clock, ClockType
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from std_msgs.msg import String

from .metrics import MetricsCollector
from .protocol import encode_status


class StatusPublisher(Node):
    def __init__(self, **kwargs):
        super().__init__('system_status_publisher', **kwargs)
        # 启动参数设为只读，避免 ros2 param set 成功但定时器没更新的歧义。
        readonly = ParameterDescriptor(read_only=True)
        self.declare_parameter('publish_period', 1.0, readonly)
        self.declare_parameter('topic', '/system/status', readonly)
        self.declare_parameter('network_interface', '', readonly)
        self.declare_parameter('log_file', '', readonly)
        period = self.get_parameter('publish_period').value
        if not math.isfinite(period) or period < 0.1:
            raise ValueError('publish_period 必须是 >= 0.1 的有限秒数')
        self.collector = MetricsCollector(self.get_parameter('network_interface').value)
        self.publisher = self.create_publisher(
            String, self.get_parameter('topic').value, 1)
        self.log_stream = None
        log_file = self.get_parameter('log_file').value
        if log_file:
            path = Path(log_file).expanduser()
            path.parent.mkdir(parents=True, exist_ok=True)
            self.log_stream = path.open('a', encoding='utf-8', buffering=1)
        # 监看真实主机，使用单调时钟；不依赖 /clock 或仿真暂停状态。
        self.timer = self.create_timer(
            period, self.publish_status, clock=Clock(clock_type=ClockType.STEADY_TIME))
        self.get_logger().info(
            f'每 {period:g} 秒发布至 {self.publisher.topic_name}')

    def publish_status(self):
        try:
            text = encode_status(self.collector.sample())
        except (OSError, ValueError) as exc:
            self.get_logger().error(f'本次采集失败：{exc}')
            return
        self.publisher.publish(String(data=text))
        if self.log_stream:
            try:
                self.log_stream.write(text + '\n')
            except OSError as exc:
                self.get_logger().error(f'写入日志失败，停止记录，继续发布：{exc}')
                try:
                    self.log_stream.close()
                except OSError:
                    pass
                self.log_stream = None

    def destroy_node(self):
        if getattr(self, 'log_stream', None):
            try:
                self.log_stream.close()
            except OSError:
                pass
            self.log_stream = None
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = StatusPublisher()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
