"""两个 Python 包共用的 JSON 数据契约，不依赖 ROS 或 Qt。"""

import json
import math
from datetime import datetime


def validate_status(data):
    """拒绝缺字段、无穷值和错误类型，防止坏消息中断 GUI。"""
    if not isinstance(data, dict):
        raise ValueError('消息必须是 JSON 对象')
    if type(data.get('schema_version')) is not int or data['schema_version'] != 1:
        raise ValueError('不支持的 schema_version')
    for key in ('timestamp', 'hostname', 'network_interface'):
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError(f'{key} 必须是非空字符串')
    try:
        stamp = datetime.fromisoformat(data['timestamp'])
    except ValueError as exc:
        raise ValueError('timestamp 必须是 ISO 8601 时间') from exc
    if stamp.tzinfo is None:
        raise ValueError('timestamp 必须带时区')
    for key in ('sequence', 'memory_total_bytes', 'memory_available_bytes',
                'memory_free_bytes', 'network_received_bytes', 'network_sent_bytes'):
        if type(data.get(key)) is not int or data[key] < 0:
            raise ValueError(f'{key} 必须是非负整数')
    if data['memory_total_bytes'] == 0:
        raise ValueError('内存总量必须大于 0')
    for key in ('memory_available_bytes', 'memory_free_bytes'):
        if data[key] > data['memory_total_bytes']:
            raise ValueError(f'{key} 超出内存总量')
    for key in ('cpu_percent', 'memory_percent', 'network_receive_bytes_per_sec',
                'network_send_bytes_per_sec', 'sample_interval_sec'):
        value = data.get(key)
        if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
            raise ValueError(f'{key} 必须是有限的非负数')
    if data['cpu_percent'] > 100 or data['memory_percent'] > 100:
        raise ValueError('使用率不能大于 100')
    if data['sample_interval_sec'] <= 0:
        raise ValueError('采样间隔必须大于 0')
    return data


def encode_status(data):
    return json.dumps(validate_status(data), ensure_ascii=False, allow_nan=False)


def decode_status(text):
    # 正常消息不足 2 KiB；限制解析长度，避免误发大文本卡住界面。
    if len(text) > 16384:
        raise ValueError('状态消息过长')
    return validate_status(json.loads(text))
