"""psutil 采集逻辑；可脱离 ROS 单独测试。"""

import socket
import time
from datetime import datetime, timezone

import psutil


def network_rate(previous, current, elapsed):
    """同一网卡计数器的增量 / 单调时钟间隔；重置后不产生负网速。"""
    if elapsed <= 0 or previous.keys() != current.keys():
        return 0.0, 0.0
    received = sent = 0
    for name, (rx, tx) in current.items():
        old_rx, old_tx = previous[name]
        # 网卡重新连接或计数器重置时，本轮不估算这块网卡的速率。
        if rx >= old_rx and tx >= old_tx:
            received += rx - old_rx
            sent += tx - old_tx
    return received / elapsed, sent / elapsed


class MetricsCollector:
    def __init__(self, interface='', provider=None, clock=None, wall_clock=None):
        self.provider = provider if provider is not None else psutil
        self.clock = clock if clock is not None else time.monotonic
        self.wall_clock = wall_clock or (lambda: datetime.now(timezone.utc))
        self.interface = interface.strip()
        self.hostname = socket.gethostname()
        self.sequence = 0
        # 第一次非阻塞 cpu_percent 是基准值，不能直接用于展示。
        self.provider.cpu_percent(interval=None)
        self.previous_network = self._read_network()
        self.previous_time = self.clock()

    def _read_network(self):
        counters = self.provider.net_io_counters(pernic=True, nowrap=True) or {}
        if self.interface:
            if self.interface not in counters:
                raise ValueError(f'找不到网卡 {self.interface!r}；可用网卡：{list(counters)}')
            counters = {self.interface: counters[self.interface]}
        return {name: (int(value.bytes_recv), int(value.bytes_sent))
                for name, value in counters.items()}

    def sample(self):
        current = self._read_network()
        now = self.clock()
        elapsed = now - self.previous_time
        if elapsed <= 0:
            raise ValueError('两次采样需要正的时间间隔')
        receive_rate, send_rate = network_rate(self.previous_network, current, elapsed)
        memory = self.provider.virtual_memory()
        cpu = self.provider.cpu_percent(interval=None)
        self.sequence += 1
        result = {
            'schema_version': 1,
            'sequence': self.sequence,
            'timestamp': self.wall_clock().isoformat(timespec='milliseconds'),
            'hostname': self.hostname,
            'sample_interval_sec': elapsed,
            'cpu_percent': float(cpu),
            'memory_percent': float(memory.percent),
            'memory_total_bytes': int(memory.total),
            'memory_available_bytes': int(memory.available),
            'memory_free_bytes': int(memory.free),
            'network_interface': self.interface or '全部网卡（含回环）',
            'network_received_bytes': sum(value[0] for value in current.values()),
            'network_sent_bytes': sum(value[1] for value in current.values()),
            'network_receive_bytes_per_sec': receive_rate,
            'network_send_bytes_per_sec': send_rate,
        }
        self.previous_network = current
        self.previous_time = now
        return result
