"""System status acquisition and ROS 2 publishing."""
